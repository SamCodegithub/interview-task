import React, { useEffect, useState } from "react";
import { Table } from "antd";
import axios from "axios";
import { useNavigate } from "react-router";

const Home = () => {
  const [value, setValue] = useState("");
  const [userData, setUserData] = useState([]);
  const [pageSize, setPageSize] = useState(10);
  const navigate = useNavigate();

  const fetchData = async () => {
    const result = await axios(
      `https://reqres.in/api/users?page={page}&&per_page={record_per_page}`
    );
    setUserData(result?.data?.data);
  };

  useEffect(() => {
    fetchData();
  }, [value]);

  const handleChange = async (e) => {
    setValue(e.target.value);
    setPageSize(e.target.value);
    fetchData();
  };

  const columns = [
    {
      title: "ID",
      dataIndex: "id",
      key: "name",
    },
    {
      title: "Profile-Picture",
      render: (data) => (
        <div className="user-image">
          <img src={data.avatar} />
        </div>
      ),
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "age",
    },
    {
      title: "FirstName",
      dataIndex: "first_name",
      key: "address",
    },
    {
      title: "LastName",
      dataIndex: "last_name",
      key: "address",
    },

    {
      title: "Action",
      render: (data) => (
        // console.log("data",data.id)
        <label onClick={() => navigate(`details/${data.id}`)}>View</label>
      ),
    },
  ];

  return (
    <div className="container my-5 main-container d-flex justify-content-center align-items-center flex-column">
      <div className="row">
        <div className="col-lg-3">
          <select onChange={handleChange} className="form-select w-100">
            <option key="1" value="1">
              1
            </option>
            <option key="3" value="3">
              3
            </option>
            <option key="15" value="15">
              15
            </option>
          </select>
        </div>

        <div className="col-lg-12 my-5">
          <div className=" table-card card border-0 rounded-0 p-0">
            <div className="card-body p-0">
              <Table
                columns={columns}
                dataSource={userData}
                pagination={{
                  pageSize,
                  pageSizeOptions: [5, 10, 50, 100, 500],
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
