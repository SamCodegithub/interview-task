import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router";
import "./details.css";

const Details = () => {
  const [userData, setUserData] = useState([]);

  const { id } = useParams();
  const navigate = useNavigate();
  const fetchData = async () => {
    const result = await axios(
      `https://reqres.in/api/users?page={page}&&per_page={record_per_page}`
    );
    const filteredItems = result?.data?.data.filter(
      (filteredItem) => filteredItem.id == id
    );
    setUserData(filteredItems);
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div class="mainContainer">
      <div class="container1">
        <div class="user-image1">
          <img src={userData[0]?.avatar} alt="" />
        </div>

        <div class="content1">
          <h3 class="name1">{userData[0]?.first_name}</h3>
          <p class="username1">{userData[0]?.last_name}</p>

          <p class="details1">{userData[0]?.email}</p>

          <button class="backLink" onClick={() => navigate("/home")}>
            Back
          </button>
        </div>
      </div>
    </div>
  );
};

export default Details;
