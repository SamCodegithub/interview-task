import React from "react";
import { useNavigate } from "react-router";
import { ErrorMessage, Formik } from "formik";
import { validationLogin } from "./helper/validation";
import { toast } from "react-toastify";

const Login = () => {
  const navigate = useNavigate();
  const SubmiteHandler = (values) => {
    if (values.email == "smit@gmail.com" && values.password == "smit@123") {
      localStorage.setItem("userData", values.email);
      navigate("/home");
    } else {
      toast.error("Email and Password is wrong!");
    }
  };

  return (
    <Formik
      initialValues={{
        email: "",
        password: "",
      }}
      validationSchema={validationLogin}
      onSubmit={(values) => SubmiteHandler(values)}
    >
      {({
        values,
        errors,
        handleChange,
        handleBlur,
        handleSubmit,
        isSubmitting,
        touched,
      }) => (
        <div class="auth-wrapper d-flex no-block justify-content-center align-items-center">
          {console.log("error", errors)}
          <div class="child_overlay"></div>
          <div class="auth-box p-4 bg-white rounded">
            <div id="loginform">
              <div class="logo">
                <h3 class="box-title mb-3">Login</h3>
              </div>

              <div class="row">
                <div class="col-12">
                  <form
                    class="form-horizontal mt-3 form-material"
                    onSubmit={handleSubmit}
                  >
                    <div class="form-group mb-3">
                      <div class="">
                        <input
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={values.email}
                          class="form-control"
                          type="email"
                          required=""
                          placeholder="Email Id"
                          name="email"
                          autofocus="autofocus"
                        />
                        <ErrorMessage
                          name="email"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </div>
                    </div>
                    <div class="form-group mb-4">
                      <div class="">
                        <input
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={values.password}
                          class="form-control"
                          type="password"
                          required=""
                          placeholder="Password"
                          name="password"
                        />
                        <ErrorMessage
                          name="password"
                          render={(msg) => (
                            <div className="text-danger">{msg}</div>
                          )}
                        />
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="d-flex">
                        <div class="ms-auto">
                          <a
                            id="to-recover"
                            onclick="forgotPasswordDiv()"
                            class="link font-weight-medium"
                          >
                            <i class="fa fa-lock me-1"></i> Can't access your
                            account?
                          </a>
                        </div>
                      </div>
                    </div>
                    <div class="form-group text-center mt-4 mb-3">
                      <div class="col-xs-12">
                        <button
                          class="btn btn-info d-block w-100 waves-effect waves-light"
                          type="submit"
                        >
                          LOGIN
                        </button>
                      </div>
                    </div>
                    <p class="orpage">OR LOGIN WITH</p>
                    <div class="icon-style">
                      <a class="socialIcon_btn">
                        <img
                          src="https://dash.kidsnanny.com.au/kidsnanny/images/icon/google.140060f3dd810450742c1315abc08ec0.svg"
                          alt="google"
                        />
                      </a>
                      <a class="socialIcon_btn">
                        <img
                          src="https://dash.kidsnanny.com.au/kidsnanny/images/icon/icons8-gmail-logo.svg"
                          alt="gmail"
                          style={{ width: "100%" }}
                        />
                      </a>
                      <a class="socialIcon_btn">
                        <img
                          src="https://dash.kidsnanny.com.au/kidsnanny/images/icon/apple.6c0da15943fe5b51c749fd1f66ec3785.svg"
                          alt="apple"
                        />
                      </a>
                      <a class="socialIcon_btn">
                        <img
                          src="https://dash.kidsnanny.com.au/kidsnanny/images/icon/facebook.f95849398bc18f9f942efe9423a8bf5d.svg"
                          alt="facebook"
                        />
                      </a>
                    </div>
                    <div class="form-group mb-0 mt-4">
                      <div class="col-sm-12 justify-content-center d-flex">
                        <p>
                          Don't have an account?
                          <a class="text-info font-weight-medium ms-1">
                            Sign Up
                          </a>
                        </p>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </Formik>
  );
};

export default Login;
